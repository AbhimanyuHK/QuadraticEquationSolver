# Quadratic Equation 

This is to solve quadratic equations.

### Scope

* Solve quadratic equations.

### Setup and install 

``` pip install equation-solver ```



